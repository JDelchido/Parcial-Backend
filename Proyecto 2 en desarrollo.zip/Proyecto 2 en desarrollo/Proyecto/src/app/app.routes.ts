import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AgregarFincaComponent } from './components/agregar-finca/agregar-finca.component';
import { AyudaComponent } from './components/ayuda/ayuda.component';
import { BuscarComponent } from './components/buscar/buscar.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { EditarInformacionComponent } from './components/editar-informacion/editar-informacion.component';
import { FavoritoComponent } from './components/favorito/favorito.component';
import { LoginComponent } from './components/login/login.component';
import { PerfilArrendadorComponent } from './components/perfil-arrendador/perfil-arrendador.component';
import { PerfilArrendatarioComponent } from './components/perfil-arrendatario/perfil-arrendatario.component';
import { PruebaFincaComponent } from './components/prueba-finca/prueba-finca.component';
import { PruebaServiciosComponent } from './components/prueba-servicios/prueba-servicios.component';
import { PruebaSolicitudComponent } from './components/prueba-solicitud/prueba-solicitud.component';
import { ReservarComponent } from './components/reservar/reservar.component';
import { authGuard } from './auth.guard';
import setupAxiosInterceptors from './auth.interceptor';

setupAxiosInterceptors();

export const routes: Routes = [
    { path: 'login', component: LoginComponent},
    { path: 'dashboard/:id', component: DashboardComponent, canActivate: [authGuard]},
    { path: 'buscar', component: BuscarComponent, canActivate: [authGuard]},
    { path: 'favorito', component: FavoritoComponent, canActivate: [authGuard]},
    { path: 'reservar/:usuarioId/:fincaId', component: ReservarComponent},
    { path: 'ayuda/:id', component: AyudaComponent, canActivate: [authGuard]},
    { path: 'editar-informacion/:id', component: EditarInformacionComponent, canActivate: [authGuard]},
    { path: 'agregar-finca/:id', component: AgregarFincaComponent, canActivate: [authGuard]},
    { path: 'perfil-arrendatario/:id', component: PerfilArrendatarioComponent, canActivate: [authGuard]},
    { path: 'perfil-arrendador/:id', component: PerfilArrendadorComponent, canActivate: [authGuard]},
    { path: '', redirectTo: '/login', pathMatch: 'full'},
    { path: 'prueba-usuario', component: PruebaServiciosComponent},
    { path: 'prueba-finca', component: PruebaFincaComponent},
    { path: 'prueba-solicitud', component: PruebaSolicitudComponent}
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule{}
