import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from './services/auth.service';
import { inject } from '@angular/core';

export const authGuard: CanActivateFn = (route, state) => {
  const authService = inject(AuthService);
  
  if (authService.isAuthenticated()) {
    return true; // Permite el acceso si el usuario está autenticado
  } else {
    // Redirige a la página de inicio de sesión o muestra un mensaje
    const router = inject(Router);
    router.navigate(['/login']/*, { queryParams: { returnUrl: state.url } }*/);
    return false;
  }
};
