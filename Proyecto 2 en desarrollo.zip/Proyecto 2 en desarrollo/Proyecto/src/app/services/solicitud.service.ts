import { Injectable } from '@angular/core';
import { Solicitud } from '../modules/Solicitud';
import axios from 'axios';

@Injectable({
  providedIn: 'root'
})
export class SolicitudService {

  private url = 'http://locaclhost:8080/api/solicitudes';

  constructor() { }

  getUsuariosExterno(): Promise<Solicitud[]>{
    return axios.get<Solicitud[]>(`${this.url}/list`).then(response => response.data);
  }

  getSolicitudByIdExterno(id: number): Promise<Solicitud>{
    return axios.get<Solicitud>(`${this.url}/get/${id}`).then(response => response.data);
  }

  getSolicitudByArrendatarioIdExterno(arrendatarioId: number): Promise<Solicitud>{
    return axios.get<Solicitud>(`${this.url}/arrendatario/${arrendatarioId}`).then(response => response.data);
  }

  postSolicitudExterno(solicitud:Solicitud): Promise<Solicitud>{
    return axios.post<Solicitud>(`${this.url}/create`, solicitud).then(response => response.data);
  }

  updateSolicitudExterno(id: number, solicitud:Solicitud): Promise<Solicitud>{
    return axios.put<Solicitud>(`${this.url}/update/${id}`, solicitud).then(response => response.data);
  }

  deleteSolictudExterno(id: number): void{
    axios.delete<Solicitud>(`${this.url}/delete/${id}`)
  }

  calificarSolicitudExterno(solicitud:Solicitud, id: number): Promise<Solicitud>{
    return axios.put<Solicitud>(`${this.url}/calificar/${id}`, solicitud).then(response => response.data);
  }

  pagarSolicitudExterno(id: number, banco: string, numeroCuenta: number): Promise<Solicitud>{
    return axios.put<Solicitud>(`${this.url}/pagar/${id}`, {params: { id: id, numeroCuenta: numeroCuenta, banco: banco }}).then(response => response.data);
  }
}
