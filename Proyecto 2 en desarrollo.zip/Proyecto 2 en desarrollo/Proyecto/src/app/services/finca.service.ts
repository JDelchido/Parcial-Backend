import { Injectable } from '@angular/core';
import { Finca } from '../modules/Finca';
import axios from 'axios';

@Injectable({
  providedIn: 'root'
})
export class FincaService {

  private url = 'http://localhost:8080/api/finca';

  constructor() { }

  getFincasExterno(): Promise<Finca[]>{
    return axios.get<Finca[]>(`${this.url}/list`).then(response => response.data);
  }

  getFincaByIdExterno(id: number): Promise<Finca>{
    return axios.get<Finca>(`${this.url}/get/${id}`).then(response => response.data);
  }

  getFincaByNombreExterno(nombre: string): Promise<Finca>{
    return axios.get<Finca>(`${this.url}/getNom/${nombre}`).then(response => response.data);
  }

  postFincaExterno(finca:Finca): Promise<Finca>{
    return axios.post<Finca>(`${this.url}/create`, finca).then(response => response.data);
  }

  updateFincaExterno(finca:Finca): Promise<Finca>{
    return axios.put<Finca>(`${this.url}/update`, finca).then(response => response.data);
  }

  deleteFincaExterno(finca: Finca): void{
    axios.delete<Finca>(`${this.url}/delete`, {data: finca}).then(response => response.data);
  }

  calificarFincaExterno(id: number, finca: Finca): Promise<Finca>{
    return axios.put<Finca>(`${this.url}//calificar/${id}`, finca).then(response => response.data);
  }

  calificarArrendatarioExterno(solicitudId: number, finca: Finca): Promise<Finca>{
    return axios.put<Finca>(`${this.url}//calificar-arrendatario/${solicitudId}`, finca).then(response => response.data);
  }

  getFincasByUsuarioExterno(usuarioId: number): Promise<Finca[]>{
    return axios.get<Finca[]>(`${this.url}//user/${usuarioId}/arrendador`).then(response => response.data);
  }

  transferirFinca(fincaId: number, usuarioId: number): Promise<string>{
    return axios.put(`${this.url}//${fincaId}/transferir/${usuarioId}`).then(response => response.data);
  }
}
