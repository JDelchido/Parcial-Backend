import { Injectable } from '@angular/core';
import axios from 'axios';
import { Usuario } from '../modules/Usuario';

@Injectable({
  providedIn: 'root'
})
export class UsuarioService {

   private url = 'http://localhost:8080/api/usuario';

  constructor() { }

  getUsuariosExterno(): Promise<Usuario[]>{
    return axios.get<Usuario[]>(`${this.url}/list`).then(response => response.data);
  }

  getUsuarioByIdExterno(id: number): Promise<Usuario>{
    return axios.get<Usuario>(`${this.url}/get/${id}`).then(response => response.data);
  }

  getUsuarioByNombreExterno(nombre: string): Promise<Usuario>{
    return axios.get<Usuario>(`${this.url}/getNom/${nombre}`).then(response => response.data);
  }

  postUsuarioExterno(usuario: Usuario): Promise<Usuario>{
    return axios.post<Usuario>(`${this.url}/create`, usuario).then(response => response.data);
  }

  updateUsuarioExterno(usuario: Usuario): Promise<Usuario>{
    return axios.put<Usuario>(`${this.url}/update`, usuario).then(response => response.data);
  }

  deleteUsuarioExterno(usuario: Usuario): void{
    axios.delete<Usuario>(`${this.url}/delete`, {data: usuario}).then(response => response.data);
  }

  authUsuarioExterno(nombre: string, contrasena: string): Promise<boolean>{
    console.log("Nombre: " + nombre);
    console.log("Contraseña:"  + contrasena)
    return axios.post('${this.url}/login', null, {params: { nombre: nombre, contrasena: contrasena}}).then(response => response.data);
  }
}
