import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import axios from 'axios';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private url = 'http://localhost:8080/auth';

  constructor(private http: HttpClient) { }

  login(nombre: string, contrasena: string): Promise<string> {
    console.log('Nombre:', nombre);
    console.log('Contraseña:', contrasena);
    const params = new URLSearchParams({ nombre, contrasena });
    return axios
    .post<string>(`${this.url}/login?${params.toString()}`)
    .then(response => response.data)
    .catch(error => {
      console.error('Error en el login:', error);
      throw error;
    });
  }

  logout(): void {
    localStorage.removeItem('token');
  }

  setToken(token: string): void {
    localStorage.setItem('token', token);
  }

  getToken(): string | null {
    return localStorage.getItem('token');
  }

  isAuthenticated(): boolean {
    const token = this.getToken();
    return !!token;
  }
}
