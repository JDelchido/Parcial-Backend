import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { Finca } from '../../modules/Finca';
import { Usuario } from '../../modules/Usuario';
import { FincaService } from '../../services/finca.service';
import { UsuarioService } from '../../services/usuario.service';
import { FavoritoComponent } from "../favorito/favorito.component";

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule, FavoritoComponent],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class DashboardComponent implements OnInit{
  id: number = 1;

  fincas: Finca[] = [];

  constructor(
    private usuarioService: UsuarioService,
    private fincaService: FincaService,
    private route: ActivatedRoute,
    private router: Router,
  ){}

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.id = params['id'];
    });

    this.fincaService.getFincasExterno().then((post) => {
      this.fincas = post;
    }).catch((error) => {
      console.error(error);
    })
  }

  perfil(){
    let usuario: Usuario | null = null;
    let tipo: string | null | undefined = null;
    this.usuarioService.getUsuarioByIdExterno(this.id).then((get) => {
      usuario = get;
      if(usuario)
      {
        tipo = usuario.tipo;
        if(tipo == "ARRENDATARIO"){
          this.router.navigate(['/perfil-arrendatario', this.id]);
        }
        else if(tipo == "ARRENDADOR"){
          this.router.navigate(['/perfil-arrendador', this.id]);
        }
      }
    }).catch((error) =>{
      console.error(error);
    })
  }

  reserva(fincaId: number){
    this.router.navigate(['/reservar', this.id, fincaId]);
  }

  ayuda(){
    this.router.navigate(['/ayuda', this.id]);
  }
  redirigirReserva(finca: any): void {
    // Lógica de redirección usando el nombre de la finca (puedes cambiar según necesites)
    this.router.navigate(['/reserva'], { queryParams: { finca: finca.nombre } });
  }
}
