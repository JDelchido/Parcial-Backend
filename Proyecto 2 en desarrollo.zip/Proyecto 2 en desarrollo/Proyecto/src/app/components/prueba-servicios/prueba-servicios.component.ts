import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Usuario } from '../../modules/Usuario';
import { UsuarioService } from '../../services/usuario.service';
import { RouterModule } from '@angular/router';


@Component({
  selector: 'app-prueba-servicios',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './prueba-servicios.component.html',
  styleUrl: './prueba-servicios.component.css'
})
export class PruebaServiciosComponent implements OnInit{

  usuarios: Usuario[] = [];
  usuario: Usuario | null = null;
  nuevoUsuario: Usuario = new Usuario(); // Usuario a crear
  usuarioActualizado: Usuario | null = null;

  constructor(private usuarioService: UsuarioService) { }
  
  ngOnInit(): void {
    this.getUsuarios();
    this.getUsuarioById(1);
    this.getUsuarioByNombre('John');
    this.crearUsuario();  // Llamar al método para crear un usuario de prueba
    this.actualizarUsuario(); // Llamar al método para actualizar un usuario de prueba
  }

  getUsuarios(): void {
    this.usuarioService.getUsuariosExterno()
      .then(data => {
        this.usuarios = data;
        console.log('Lista de usuarios:', this.usuarios);
      })
      .catch(error => console.error('Error al obtener usuarios:', error));
  }

  getUsuarioById(id: number): void {
    this.usuarioService.getUsuarioByIdExterno(id)
      .then(data => {
        this.usuario = data;
        console.log(`Usuario con ID ${id}:`, this.usuario);
      })
      .catch(error => console.error(`Error al obtener usuario con ID ${id}:`, error));
  }

  getUsuarioByNombre(nombre: string): void {
    this.usuarioService.getUsuarioByNombreExterno(nombre)
      .then(data => {
        this.usuario = data;
        console.log(`Usuario con nombre ${nombre}:`, this.usuario);
      })
      .catch(error => console.error(`Error al obtener usuario con nombre ${nombre}:`, error));
  }

  // Crear un usuario
  crearUsuario(): void {
    const nuevoUsuario: Usuario = {
      nombre: 'Nuevo',
      apellido: 'Usuario',
      correo: 'nuevo.usuario@example.com',
      telefono: 5555555,
      contrasena: 'password123',
      tipo: 'ARRENDADOR',  // Cambiar según corresponda
      calificacion: 5
    };

    this.usuarioService.postUsuarioExterno(nuevoUsuario)
      .then(data => {
        console.log('Usuario creado:', data);
        this.getUsuarios(); // Refrescar la lista de usuarios después de crear uno nuevo
      })
      .catch(error => console.error('Error al crear usuario:', error));
  }

  // Actualizar un usuario
  actualizarUsuario(): void {
    this.usuarioService.getUsuarioByIdExterno(1)  // Obtener un usuario existente
      .then(data => {
        if (data) {
          this.usuarioActualizado = { ...data, nombre: 'Nombre Actualizado' }; // Actualizar el nombre del usuario
          this.usuarioService.updateUsuarioExterno(this.usuarioActualizado)
            .then(updatedUsuario => {
              console.log('Usuario actualizado:', updatedUsuario);
              this.getUsuarios(); // Refrescar la lista de usuarios después de la actualización
            })
            .catch(error => console.error('Error al actualizar usuario:', error));
        }
      })
      .catch(error => console.error('Error al obtener usuario para actualizar:', error));
  }

  // Eliminar un usuario
  eliminarUsuario(): void {
    this.usuarioService.getUsuarioByIdExterno(2)  // Obtener un usuario existente
      .then(data => {
        if (data) {
          this.usuarioService.deleteUsuarioExterno(data);
          console.log('Usuario eliminado:', data);
          this.getUsuarios(); // Refrescar la lista de usuarios después de eliminar uno
        }
      })
      .catch(error => console.error('Error al obtener usuario para eliminar:', error));
  }
}
