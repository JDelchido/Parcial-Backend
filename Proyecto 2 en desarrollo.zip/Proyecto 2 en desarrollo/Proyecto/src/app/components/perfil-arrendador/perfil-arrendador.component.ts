import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UsuarioService } from '../../services/usuario.service';
import { Usuario } from '../../modules/Usuario';
import { Finca } from '../../modules/Finca';
import { CommonModule } from '@angular/common';
import { FincaService } from '../../services/finca.service';

@Component({
  selector: 'app-perfil-arrendador',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './perfil-arrendador.component.html',
  styleUrl: './perfil-arrendador.component.css'
})
export class PerfilArrendadorComponent implements OnInit{
  id: number = 1;

  usuario: Usuario | null = null;

  fincas: Finca[] = [];

  constructor(
    private usuarioService: UsuarioService,
    private fincaService: FincaService,
    private route: ActivatedRoute,
    private router: Router,
  ){}

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.id = params['id'];
    });

    this.usuarioService.getUsuarioByIdExterno(this.id).then((get) => {
      this.usuario = get;
    }).catch((error) =>{
      console.error(error);
    })

    this.fincaService.getFincasByUsuarioExterno(this.id).then((get) => {
      this.fincas = get;
    }).catch((error) =>{
      console.error(error);
    })
  }

  irAEditar(){
    this.router.navigate(['/editar-informacion', this.id]);
  }

  irAAgregar(){
    this.router.navigate(['/agregar-finca', this.id]);
  }

}
