import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { UsuarioService } from '../../services/usuario.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Usuario } from '../../modules/Usuario';
import { Finca } from '../../modules/Finca';
import { FincaService } from '../../services/finca.service';

@Component({
  selector: 'app-agregar-finca',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './agregar-finca.component.html',
  styleUrl: './agregar-finca.component.css'
})
export class AgregarFincaComponent implements OnInit{

  id: number = 1;

  usuario: Usuario | null = null;
  finca: Finca | null = {
    nombre: "Finca de Prueba",
    ubicacion: "Ubicación de Prueba",
    descripcion: "Descripción de prueba para la finca.",
    capacidad: 10,
    departamento: "Departamento de Prueba",
    municipio: "Municipio de Prueba",
    precioDefecto: 100.00
  };
  finca2: Finca | null = null;

  infoFinca: any = {
    "nombre": "",
    "ubicacion": "",
    "descripcion": "",
    "capacidad": "",
    "departamento": "",
    "municipio": "",
    "precio": ""
  }

  constructor(
    private usuarioService: UsuarioService,
    private fincaService: FincaService,
    private route: ActivatedRoute,
    private router: Router
  ){}

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.id = params['id'];
    });

    this.usuarioService.getUsuarioByIdExterno(this.id).then((get) => {
      this.usuario = get;
    }).catch((error) =>{
      console.error(error);
    });
  }
 
  agregar(){ 
    if(this.infoFinca.nombre && this.finca && this.usuario){
      this.finca.nombre = this.infoFinca.nombre;
      this.finca.ubicacion = this.infoFinca.ubicacion;
      this.finca.descripcion = this.infoFinca.descripcion;
      this.finca.capacidad = this.infoFinca.capacidad;
      this.finca.departamento = this.infoFinca.departamento;
      this.finca.municipio = this.infoFinca.municipio;
      this.finca.precioDefecto = this.infoFinca.precio;
      this.finca.calificacion = null;
      this.finca.id = null;

      this.fincaService.postFincaExterno(this.finca).then((post) => {
        this.finca2 = post;
        const fincaId = this.finca2.id;
        /*this.fincaService.transferirFinca(fincaId, this.usuario?.id).then((put) => {

        })*/
      }).catch((error) =>{
        console.error(error);
      });
    }
  }
}
