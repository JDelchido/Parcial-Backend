import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Usuario } from '../../modules/Usuario';
import { UsuarioService } from '../../services/usuario.service';

@Component({
  selector: 'app-editar-informacion',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './editar-informacion.component.html',
  styleUrl: './editar-informacion.component.css'
})
export class EditarInformacionComponent implements OnInit{
  id: number = 1;

  usuario: Usuario | null = null;

  infoEditar: any = {
    "nombre": "",
    "apellido": "",
    "correo": "",
    "telefono": "",
    "contrasena": ""
  }

  constructor(
    private usuarioService: UsuarioService,
    private route: ActivatedRoute,
    private router: Router,
  ){}

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.id = params['id'];
    });

    this.usuarioService.getUsuarioByIdExterno(this.id).then((get) => {
      this.usuario = get;
    }).catch((error) =>{
      console.error(error);
    });
  }

  editar(){
    let tipo: string | null | undefined = null;
    let usuario: Usuario | null | undefined = null;
    if(this.usuario)
    {
      if(this.infoEditar.nombre != ""){
        this.usuario.nombre = this.infoEditar.nombre;
      }
      if(this.infoEditar.apellido != ""){
        this.usuario.apellido = this.infoEditar.apellido;
      }
      if(this.infoEditar.correo != ""){
        this.usuario.correo = this.infoEditar.correo;
      }
      if(this.infoEditar.telefono != ""){
        this.usuario.telefono = this.infoEditar.telefono;
      }
      if(this.infoEditar.contrasena != ""){
        this.usuario.contrasena = this.infoEditar.contrasena;
      }

      this.usuarioService.updateUsuarioExterno(this.usuario).then((put) => {
        usuario = put;
        if(usuario)
          {
            tipo = usuario.tipo;
            if(tipo == "ARRENDATARIO"){
              this.router.navigate(['/perfil-arrendatario', this.id]);
            }
            else if(tipo == "ARRENDADOR"){
              this.router.navigate(['/perfil-arrendador', this.id]);
            }
          }
      }).catch((error) =>{
        console.error(error);
      })
    }
  }
}
