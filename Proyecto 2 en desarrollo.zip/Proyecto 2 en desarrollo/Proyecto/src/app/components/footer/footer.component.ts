import { Component } from '@angular/core';
import { Finca } from '../../modules/Finca';

@Component({
  selector: 'app-footer',
  standalone: true,
  imports: [],
  templateUrl: './footer.component.html',
  styleUrl: './footer.component.css'
})
export class FooterComponent {
  id: number = 1;
  currentYear: number = new Date().getFullYear();
}
