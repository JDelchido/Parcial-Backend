import { CommonModule, NgFor, NgIf } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Finca } from '../../modules/Finca';
import { Usuario } from '../../modules/Usuario';
import { FincaService } from '../../services/finca.service';
import { SolicitudService } from '../../services/solicitud.service';
import { UsuarioService } from '../../services/usuario.service';

@Component({
  selector: 'app-reservar',
  standalone: true,
  imports: [CommonModule, FormsModule, NgIf, NgFor],
  templateUrl: './reservar.component.html',
  styleUrl: './reservar.component.css'
})
export class ReservarComponent implements OnInit {
  usuarioId: number = 1;

  fincaId: number = 1;

  usuario: Usuario | null = null;

  finca: Finca | null = null;

  costo = 0;

  dias = 1;

  constructor(
    private usuarioService: UsuarioService,
    private fincaService: FincaService,
    private solicitudService: SolicitudService,
    private route: ActivatedRoute,
    private router: Router
  ){}
  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.usuarioId = params['usuarioId'];
      this.fincaId = params['fincaId'];
    });

    this.usuarioService.getUsuarioByIdExterno(this.usuarioId).then((get1) => {
      this.usuario = get1;
    }).catch((error) =>{
      console.error(error);
    });

    this.fincaService.getFincaByIdExterno(this.fincaId).then((get2) => {
      this.finca = get2
    }).catch((error) =>{
      console.error(error);
    });
  }

  calcularCosto(dias: number): number{
    if(this.finca && this.finca.precioDefecto){

      this.costo = this.finca.precioDefecto * dias;
      return this.costo;
    }
    return 10;
  }

  reservar(){
    const fechaActual = new Date();
    const fechaConDiasSumados = this.sumarDias(fechaActual, 10);
  }

  sumarDias(fecha: Date, dias: number): Date {
    const nuevaFecha = new Date(fecha);
    nuevaFecha.setDate(nuevaFecha.getDate() + dias);
    return nuevaFecha;
  }
}
