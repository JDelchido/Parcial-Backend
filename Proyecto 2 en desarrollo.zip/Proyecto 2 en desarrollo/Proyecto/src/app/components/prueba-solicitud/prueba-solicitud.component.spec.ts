import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PruebaSolicitudComponent } from './prueba-solicitud.component';

describe('PruebaSolicitudComponent', () => {
  let component: PruebaSolicitudComponent;
  let fixture: ComponentFixture<PruebaSolicitudComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PruebaSolicitudComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PruebaSolicitudComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
