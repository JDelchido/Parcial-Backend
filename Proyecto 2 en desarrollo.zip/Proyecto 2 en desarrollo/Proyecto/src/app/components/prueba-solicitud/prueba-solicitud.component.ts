import { Component } from '@angular/core';
import { Solicitud } from '../../modules/Solicitud';
import { SolicitudService } from '../../services/solicitud.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-prueba-solicitud',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './prueba-solicitud.component.html',
  styleUrl: './prueba-solicitud.component.css'
})
export class PruebaSolicitudComponent {
  solicitudes: Solicitud[] = [];
  errorMessage: string = '';

  constructor(private solicitudService: SolicitudService) {}

  ngOnInit(): void {
    this.loadSolicitudes();
  }

  loadSolicitudes(): void {
    this.solicitudService.getUsuariosExterno()
      .then(data => {
        this.solicitudes = data;
      })
      .catch(error => {
        this.errorMessage = 'Error loading solicitudes';
      });
  }

  createSolicitud(): void {
    const newSolicitud = new Solicitud(null, new Date(), new Date(), 5, 4, 1000, 4, '123456', 'Banco A', 'Pendiente', true, false);
    this.solicitudService.postSolicitudExterno(newSolicitud)
      .then(data => {
        this.solicitudes.push(data);
      })
      .catch(error => {
        this.errorMessage = 'Error creating solicitud';
      });
  }
}
