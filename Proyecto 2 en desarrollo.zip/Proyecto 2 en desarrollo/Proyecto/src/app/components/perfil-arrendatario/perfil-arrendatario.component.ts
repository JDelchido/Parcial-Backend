import { Component, OnInit } from '@angular/core';
import { UsuarioService } from '../../services/usuario.service';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { Usuario } from '../../modules/Usuario';

@Component({
  selector: 'app-perfil-arrendatario',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './perfil-arrendatario.component.html',
  styleUrl: './perfil-arrendatario.component.css'
})
export class PerfilArrendatarioComponent implements OnInit{

  id: number = 1;

  usuario: Usuario | null = null;

  constructor(
    private usuarioService: UsuarioService,
    private route: ActivatedRoute,
    private router: Router
  ){}

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.id = params['id'];
    });

    this.usuarioService.getUsuarioByIdExterno(this.id).then((get) => {
      this.usuario = get;
    }).catch((error) =>{
      console.error(error);
    })
  }

}
