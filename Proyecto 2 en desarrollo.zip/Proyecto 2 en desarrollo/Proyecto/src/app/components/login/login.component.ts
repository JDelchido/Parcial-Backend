import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { UsuarioService } from '../../services/usuario.service';
import { RouterModule } from '@angular/router';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms'
import { AuthService } from '../../services/auth.service';
@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent{
  
  loginObj: any = {
    "Nombre": "",
    "Contrasena": ""
  };

  id: number | undefined |null = null;

  acceso: boolean = false;

  constructor(
    private route: Router,
    private usuarioService: UsuarioService,
    private authService: AuthService,
  ){}

  Acceder(){
    const nombre = this.loginObj.Nombre;
    const contrasena = this.loginObj.Contrasena;
    this.authService.login(nombre, contrasena).then(
      (token) => {
        console.log('Login exitoso, token recibido:', token);
        localStorage.setItem('token', token); // Guarda el token para solicitudes futuras
        this.usuarioService.getUsuarioByNombreExterno(nombre).then((get) => {
          if(get){
            this.id = get.id;
            this.route.navigate(['/dashboard', this.id]);
          }
        }).catch((error) =>{
          console.error(error);
      })
        
      },
      (error) => {
        console.error('Error al iniciar sesión:', error);
      }
    );
  }
}
