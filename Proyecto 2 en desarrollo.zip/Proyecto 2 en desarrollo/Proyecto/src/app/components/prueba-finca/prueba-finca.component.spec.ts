import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PruebaFincaComponent } from './prueba-finca.component';

describe('PruebaFincaComponent', () => {
  let component: PruebaFincaComponent;
  let fixture: ComponentFixture<PruebaFincaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PruebaFincaComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PruebaFincaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
