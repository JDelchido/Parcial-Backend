import { Component } from '@angular/core';
import { Finca } from '../../modules/Finca';
import { FincaService } from '../../services/finca.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-prueba-finca',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './prueba-finca.component.html',
  styleUrl: './prueba-finca.component.css'
})
export class PruebaFincaComponent {
  fincas: Finca[] = [];
  selectedFinca: Finca | null = null;
  errorMessage: string = '';

  constructor(private fincaService: FincaService) {}

  ngOnInit(): void {
    this.getFincas();
  }

  getFincas(): void {
    this.fincaService.getFincasExterno().then(fincas => {
      this.fincas = fincas;
    }).catch(error => {
      this.errorMessage = 'Error al obtener fincas: ' + error;
    });
  }

  getFincaById(id: number): void {
    this.fincaService.getFincaByIdExterno(id).then(finca => {
      this.selectedFinca = finca;
    }).catch(error => {
      this.errorMessage = 'Error al obtener finca: ' + error;
    });
  }

  createFinca(newFinca: Finca): void {
    this.fincaService.postFincaExterno(newFinca).then(finca => {
      this.fincas.push(finca);
    }).catch(error => {
      this.errorMessage = 'Error al crear finca: ' + error;
    });
  }
}
