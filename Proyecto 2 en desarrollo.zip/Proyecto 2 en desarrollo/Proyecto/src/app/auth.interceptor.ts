import { HttpInterceptorFn } from '@angular/common/http';
import { AuthService } from './services/auth.service';
import { inject } from '@angular/core';
import axios from 'axios';

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const authService = inject(AuthService); // Inyectar AuthService
  const token = authService.getToken();

  console.log('Token actual:', token);

  if (token || req.url.includes('/auth/login') || req.url.includes('/auth/register')) {
    const clonedRequest = req.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`,
      },
    });
    return next(clonedRequest);
  }

  return next(req);
};

const setupAxiosInterceptors = () => {
  axios.interceptors.request.use(
    (config) => {
      console.log('AuthInterceptor está funcionando:', config);

      // Agrega encabezados personalizados como Authorization
      const token = localStorage.getItem('token'); // Obtén el token desde almacenamiento local
      console.log('Token enviado: ', token);
      if (token) {
        config.headers['Authorization'] = `Bearer ${token}`;
      }

      return config;
    },
    (error) => {
      // Manejo de errores antes de enviar la solicitud
      console.error('Error en la configuración del interceptor:', error);
      return Promise.reject(error);
    }
  );

  axios.interceptors.response.use(
    (response) => {
      // Manejo de respuestas exitosas
      return response;
    },
    (error) => {
      // Manejo de errores de la respuesta
      if (error.response?.status === 401) {
        console.warn('Sesión no autorizada. Redirigiendo al login...');
        // Redirige al usuario al login si es necesario
      }
      return Promise.reject(error);
    }
  );
};

export default setupAxiosInterceptors;
