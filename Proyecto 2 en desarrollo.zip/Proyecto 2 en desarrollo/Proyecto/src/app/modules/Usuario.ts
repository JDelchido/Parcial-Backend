export class Usuario{
    constructor(
        public id?: number | null,
        public nombre?: string | null,
        public apellido?: string | null,
        public correo?: string | null,
        public telefono?: number | null,
        public contrasena?: string | null,
        public calificacion?: number | null,
        public tipo?: string | null
    ){}
}