export class Solicitud{
    constructor(
        public id?: number | null,
        public fechaInicio?: Date | null,
        public fechaFin?: Date | null,
        public califFinca?: number | null,
        public califArrendatario?: number | null,
        public precio?: number | null,
        public cantPersonas?: number | null,
        public numeroCuenta?: string | null,
        public banco?: string | null, 
        public estado?: string | null,
        public isPagoVisibles?: boolean | null,
        public isCalificacionVisible?: boolean | null
    ){}
}