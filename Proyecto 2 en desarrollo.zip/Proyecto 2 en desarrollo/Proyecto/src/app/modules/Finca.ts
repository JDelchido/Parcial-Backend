export class Finca{
    constructor(
        public id?: number | null,
        public nombre?: string | null,
        public ubicacion?: string | null,
        public disponible?: boolean | null,
        public calificacion?: number | null,
        public descripcion?: string | null,
        public capacidad?: number | null,
        public departamento?: string | null,
        public municipio?: string | null,
        public precioDefecto?: number | null
    ){}
}