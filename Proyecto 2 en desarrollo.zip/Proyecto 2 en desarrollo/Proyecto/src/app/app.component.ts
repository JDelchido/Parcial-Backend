import { Component } from '@angular/core';
import { RouterModule, RouterOutlet } from '@angular/router';
import { CommonModule } from '@angular/common';
import { LoginComponent } from './components/login/login.component';
import { PruebaServiciosComponent } from "./components/prueba-servicios/prueba-servicios.component";
import { BuscarComponent } from './components/buscar/buscar.component';
import { PruebaFincaComponent } from './components/prueba-finca/prueba-finca.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterModule, RouterOutlet, LoginComponent, BuscarComponent, PruebaFincaComponent, PruebaServiciosComponent, PruebaServiciosComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'Proyecto';
}
